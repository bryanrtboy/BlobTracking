/*
* UniOSC
* Copyright © 2014 Stefan Schlupek
* All rights reserved
* info@monoflow.org
*/
using UnityEngine;
using UnityEditor;
using System.Collections;

namespace UniOSC{

	/// <summary>
	/// Editor for the UniOSCSixenseInput component.
	/// </summary>
	[CustomEditor(typeof(UniOSCSixenseInput))]
	[CanEditMultipleObjects]
	public class UniOSCSixenseInputEditor : UniOSCEventDispatcherEditor {

		protected SerializedProperty sendIntervalProp;


		override public void OnEnable () {
			base.OnEnable();
			sendIntervalProp = serializedObject.FindProperty("sendInterval");
		}

		override public void OnInspectorGUI(){

			serializedObject.Update();
			EditorGUI.BeginChangeCheck();
			base.OnInspectorGUI();

			EditorGUILayout.PropertyField(sendIntervalProp,new GUIContent("Send Interval","The interval in milliseconds to send OSC data.") );

		
			serializedObject.ApplyModifiedProperties();

			if(EditorGUI.EndChangeCheck()){
				_target.enabled = !_target.enabled;
				_target.enabled = !_target.enabled;
			}

		}

	}
}
