/*
* UniOSC
* Copyright © 2014 Stefan Schlupek
* All rights reserved
* info@monoflow.org
*/
using UnityEngine;

namespace UniOSC{

	/// <summary>
	/// This class needs the SpaceNavigator Asset from Patrik Hogenboom : https://www.assetstore.unity3d.com/en/#!/content/9774
	/// You could send the translation and rotation of the SpaceNavigator as OSC message.
	/// OSC doesn't support Vector3 as data structure so we send only floats:
	/// data[0] Translation.x, data[1] Translation.y,data[2] Translation.z
	/// data[3] Rotation.eulerAngles.x, data[4] Rotation.eulerAngles.y,data[5] Rotation.eulerAngles.z
	/// To prevent data overflow you can specify the time interval in milliseconds to send the data.
	/// </summary>
	[AddComponentMenu("UniOSC/UniOSCSpaceNavigator")]
	public class UniOSCSpaceNavigator : UniOSCEventDispatcher {
		public bool HorizonLock = true;

		private Vector3 _currentTranslation = Vector3.zero;
		private Vector3 _currentRotationEuler = Vector3.zero;

	
		public override void OnEnable ()
		{

			//Here we setup our OSC message
			base.OnEnable ();
			//now we could add data;
			AppendData(0f);//Translation.x
			AppendData(0f);//Translation.y
			AppendData(0f);//Translation.z

			AppendData(0f);//Rotation.x
			AppendData(0f);//Rotation.y
			AppendData(0f);//Rotation.z

			StartSendIntervalTimer();

		}

		public override void OnDisable ()
		{
			base.OnDisable ();
			StopSendIntervalTimer();
		}



		void FixedUpdate(){
			_Update();
		}
		protected override void _Update ()
		{

			base._Update ();

			if(SpaceNavigator.Instance == null) return;

			_currentTranslation =SpaceNavigator.Translation;
			_currentRotationEuler = SpaceNavigator.Rotation.eulerAngles;

			_OSCeArg.Message.UpdateDataAt(0,_currentTranslation.x);
			_OSCeArg.Message.UpdateDataAt(1,_currentTranslation.y);
			_OSCeArg.Message.UpdateDataAt(2,_currentTranslation.z);

			_OSCeArg.Message.UpdateDataAt(3,_currentRotationEuler.x);
			_OSCeArg.Message.UpdateDataAt(4,_currentRotationEuler.y);
			_OSCeArg.Message.UpdateDataAt(5,_currentRotationEuler.z);

			//only send OSC messages at our specified interval
			lock(_mylock){
				if(!_isOSCDirty)return;
				_isOSCDirty = false;
			}

			_SendOSCMessage(_OSCeArg);
		
		}


	}

}
