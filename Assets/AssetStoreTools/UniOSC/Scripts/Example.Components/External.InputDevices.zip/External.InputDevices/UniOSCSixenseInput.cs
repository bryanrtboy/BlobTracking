/*
* UniOSC
* Copyright © 2014 Stefan Schlupek
* All rights reserved
* info@monoflow.org
*/
using UnityEngine;
using System.Collections;
using System.Runtime.InteropServices;
using System;


namespace UniOSC{

	/// <summary>
	/// This class needs the SixenseInput Asset from Sixsense Studios: https://www.assetstore.unity3d.com/en/#!/content/7953
	/// based on code from Sixense Driver Unity Plugin Copyright (C) 2013 Sixense Entertainment Inc.
	/// </summary>
	/// <remarks>
	/// </remarks>
	public class UniOSCSixenseInput : UniOSCEventDispatcher
	{

		/// <summary>
		/// Max number of controllers allowed by driver.
		/// </summary>
		public const uint MAX_CONTROLLERS = 4;
		
		/// <summary>
		/// Access to Controller objects.
		/// </summary>
		public static SixenseInput.Controller[] Controllers { get { return m_Controllers; } }
		
		/// <summary>
		/// Gets the Controller object bound to the specified hand.
		/// </summary>
		public static SixenseInput.Controller GetController( SixenseHands hand )
		{
			for ( int i = 0; i < MAX_CONTROLLERS; i++ )
			{
				if ( ( m_Controllers[i] != null ) && ( m_Controllers[i].Hand == hand ) )
				{
					return m_Controllers[i];
				}
			}
			
			return null;
		}
		
		/// <summary>
		/// Returns true if the base for zero-based index i is connected.
		/// </summary>
		public static bool IsBaseConnected( int i )
		{
			return ( SixensePlugin.sixenseIsBaseConnected( i ) != 0 );
		}
		
		/// <summary>
		/// Enable or disable the controller manager.
		/// </summary>
		public static bool ControllerManagerEnabled = true;
		
		private enum ControllerManagerState
		{
			NONE,
			BIND_CONTROLLER_ONE,
			BIND_CONTROLLER_TWO,
		}
		
		private static SixenseInput.Controller[] m_Controllers = new SixenseInput.Controller[MAX_CONTROLLERS];
		private ControllerManagerState m_ControllerManagerState = ControllerManagerState.NONE;

		private Vector3 _currentTranslation = Vector3.zero;
		private Vector3 _currentRotationEuler = Vector3.zero;



		public override void OnEnable ()
		{
			//Here we setup our OSC message
			base.OnEnable ();

			//now we could add data;
			//Trigger,JoystickX,JoystickY,Position,Rotation,GetButton,GetButtonDown,GetButtonUp
			AppendData(0f);//Trigger
			AppendData(0f);//JoystickX
			AppendData(0f);//JoystickY

			AppendData(0f);//Position.x
			AppendData(0f);//Position.y
			AppendData(0f);//Position.z

			AppendData(0f);//Rotation.eulerAngles.x
			AppendData(0f);//Rotation.eulerAngles.y
			AppendData(0f);//Rotation.eulerAngles.z

			AppendData(0f);//GetButton(START)
			AppendData(0f);//GetButton(ONE)
			AppendData(0f);//GetButton(TWO)
			AppendData(0f);//GetButton(THREE)
			AppendData(0f);//GetButton(FOUR)
			AppendData(0f);//GetButton(BUMPER)
			AppendData(0f);//GetButton(JOYSTICK)
			AppendData(0f);//GetButton(TRIGGER)

//			AppendData(0f);//Docked
//			AppendData(0f);//oGetButtonDown
//			AppendData(0f);//GetButtonUp


			SixensePlugin.sixenseInit();
			for ( int i = 0; i < MAX_CONTROLLERS; i++ )
			{
				m_Controllers[i] = new SixenseInput.Controller();
			}


			StartSendIntervalTimer();
		}


		public override void OnDisable ()
		{
			base.OnDisable ();
			StopSendIntervalTimer();
			SixensePlugin.sixenseExit();
		}

//
//		void Update(){
//			_Update();
//		}

		void FixedUpdate()
		{
			_Update();
		}

		/// <summary>
		/// Update the static controller data once per frame.
		/// The OSC data is only send in our  time interval to prevent data overflow 
		/// </summary>
		protected override void _Update()
		{
			// update controller data
			uint numControllersBound = 0;
			uint numControllersEnabled = 0;
			SixensePlugin.sixenseControllerData cd = new SixensePlugin.sixenseControllerData();
			for ( int i = 0; i < MAX_CONTROLLERS; i++ )
			{
				if ( m_Controllers[i] != null )
				{

					if ( SixensePlugin.sixenseIsControllerEnabled( i ) == 1 )
					{
						SixensePlugin.sixenseGetNewestData( i, ref cd );
						m_Controllers[i].Update( ref cd );
						m_Controllers[i].SetEnabled( true );
						numControllersEnabled++;
						if ( ControllerManagerEnabled && ( UniOSCSixenseInput.Controllers[i].Hand != SixenseHands.UNKNOWN ) )
						{

							numControllersBound++;
						}
					}
					else
					{
						m_Controllers[i].SetEnabled( false );
					}
				}
			}
			
			// update controller manager
			if ( ControllerManagerEnabled )
			{
				if ( numControllersEnabled < 2 )
				{
					m_ControllerManagerState = ControllerManagerState.NONE;
				}
					
				switch( m_ControllerManagerState )
				{
				case ControllerManagerState.NONE:
					{
						if ( IsBaseConnected( 0 ) && ( numControllersEnabled > 1 ) )
						{
							if ( numControllersBound == 0 )
							{
								m_ControllerManagerState = ControllerManagerState.BIND_CONTROLLER_ONE;
							}
							else if ( numControllersBound == 1 )
							{
								m_ControllerManagerState = ControllerManagerState.BIND_CONTROLLER_TWO;
							}
						}
					}
					break;
				case ControllerManagerState.BIND_CONTROLLER_ONE:
					{
						if ( numControllersBound > 0 )
						{
							m_ControllerManagerState = ControllerManagerState.BIND_CONTROLLER_TWO;
						}
						else
						{
							for ( int i = 0; i < MAX_CONTROLLERS; i++ )
							{
								if ( ( m_Controllers[i] != null ) && Controllers[i].GetButtonDown( SixenseButtons.TRIGGER ) && ( Controllers[i].Hand == SixenseHands.UNKNOWN ) )
								{
									Controllers[i].HandBind = SixenseHands.LEFT;
									SixensePlugin.sixenseAutoEnableHemisphereTracking( i );
									m_ControllerManagerState = ControllerManagerState.BIND_CONTROLLER_TWO;
									break;
								}
							}
						}
					}
					break;
				case ControllerManagerState.BIND_CONTROLLER_TWO:
					{
						if ( numControllersBound > 1 )
						{
							m_ControllerManagerState = ControllerManagerState.NONE;
						}
						else
						{
							for ( int i = 0; i < MAX_CONTROLLERS; i++ )
							{
								if ( ( m_Controllers[i] != null ) && Controllers[i].GetButtonDown( SixenseButtons.TRIGGER ) && ( Controllers[i].Hand == SixenseHands.UNKNOWN ) )
								{
									Controllers[i].HandBind = SixenseHands.RIGHT;
									SixensePlugin.sixenseAutoEnableHemisphereTracking( i );
									m_ControllerManagerState = ControllerManagerState.NONE;
									break;
								}
							}
						}
					}
					break;
				default:
					break;
				}
			}


		



			//only send OSC messages at our specified interval  
			lock(_mylock){
				if(!_isOSCDirty)return;
				_isOSCDirty = false;
			}
		
		
			for ( int i = 0; i < MAX_CONTROLLERS; i++ )
			{
				if ( m_Controllers[i] != null && m_Controllers[i].Enabled )
				{
					//if the Controller is Docked we don't send data
					if(m_Controllers[i].Docked) continue;

					_OSCmsg.Address = string.Format(oscOutAddress+"[{0}]",i);
					//Trigger,JoystickX,JoystickY,Position,Rotation,GetButton,Docked; //( GetButtonDown,GetButtonUp)
					_OSCeArg.Message.UpdateDataAt(0,m_Controllers[i].Trigger);
					_OSCeArg.Message.UpdateDataAt(1,m_Controllers[i].JoystickX);
					_OSCeArg.Message.UpdateDataAt(2,m_Controllers[i].JoystickY);

					_currentTranslation = m_Controllers[i].Position;
					_OSCeArg.Message.UpdateDataAt(3,_currentTranslation.x);
					_OSCeArg.Message.UpdateDataAt(4,_currentTranslation.y);
					_OSCeArg.Message.UpdateDataAt(5,_currentTranslation.z);

					_currentRotationEuler = m_Controllers[i].Rotation.eulerAngles;
					_OSCeArg.Message.UpdateDataAt(6,_currentRotationEuler.x);
					_OSCeArg.Message.UpdateDataAt(7,_currentRotationEuler.y);
					_OSCeArg.Message.UpdateDataAt(8,_currentRotationEuler.z);

					_OSCeArg.Message.UpdateDataAt(9,m_Controllers[i].GetButton(SixenseButtons.START));
					_OSCeArg.Message.UpdateDataAt(10,m_Controllers[i].GetButton(SixenseButtons.ONE));
					_OSCeArg.Message.UpdateDataAt(11,m_Controllers[i].GetButton(SixenseButtons.TWO));
					_OSCeArg.Message.UpdateDataAt(12,m_Controllers[i].GetButton(SixenseButtons.THREE));
					_OSCeArg.Message.UpdateDataAt(13,m_Controllers[i].GetButton(SixenseButtons.FOUR));
					_OSCeArg.Message.UpdateDataAt(14,m_Controllers[i].GetButton(SixenseButtons.BUMPER));
					_OSCeArg.Message.UpdateDataAt(15,m_Controllers[i].GetButton(SixenseButtons.JOYSTICK));
					_OSCeArg.Message.UpdateDataAt(16,m_Controllers[i].GetButton(SixenseButtons.TRIGGER));

//					_OSCeArg.Message.UpdateDataAt(17,m_Controllers[i].Docked);
//					_OSCeArg.Message.UpdateDataAt(10,m_Controllers[i].GetButtonDown());
//					_OSCeArg.Message.UpdateDataAt(11,m_Controllers[i].GetButtonUp);

					_SendOSCMessage(_OSCeArg);

				}
			}


		}
		
		/// <summary>
		/// Updates the controller manager GUI.
		/// </summary>
		void OnGUI()
		{
			if ( ControllerManagerEnabled && ( m_ControllerManagerState != ControllerManagerState.NONE ) )
			{
				uint boxWidth = 300;
				uint boxHeight = 24;
				string boxText = ( m_ControllerManagerState == ControllerManagerState.BIND_CONTROLLER_ONE ) ?
								 "Point left controller at base and pull trigger." :
								 "Point right controller at base and pull trigger.";
				GUI.Box( new Rect( ( ( Screen.width / 2 ) - ( boxWidth / 2 ) ), ( ( Screen.height / 2 ) - ( boxHeight / 2 ) ), boxWidth, boxHeight ), boxText );
			}
		}
		

	}

}
